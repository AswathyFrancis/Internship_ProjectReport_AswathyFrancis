package net.customer.front_end;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class Update_address {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		ChromeOptions options=new ChromeOptions();
		options.setBinary("D:\\selenium\\drivers\\Chrome\\chrome-win64\\chrome.exe");
		WebDriver driver=new ChromeDriver(options);
		Thread.sleep(3000);
		driver.get("https://www.phptravels.net/login");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
//5)Develop the script that would read from the test cases and update the address in the profile.
		
	//valid email and password
		Thread.sleep(2000);
		WebElement email=driver.findElement(By.id("email"));
		email.sendKeys("user@phptravels.com");
		WebElement pwd=driver.findElement(By.id("password"));
		pwd.sendKeys("demouser");
		Thread.sleep(2000);
		WebElement login=driver.findElement(By.id("submitBTN"));
		login.click();
		System.out.println("login successfully");
	//My profile
		Thread.sleep(2000);
		WebElement myprof=driver.findElement(By.xpath("//*[@id=\"fadein\"]/div[1]/div/div[1]/div[2]/ul/li[3]/a"));
		myprof.click();
	//Edit address1 and address 2
		Thread.sleep(2000);
		WebElement add1=driver.findElement(By.cssSelector("input[name='address1']"));
		add1.clear();
		add1.sendKeys("Demo user address 1");
		WebElement add2=driver.findElement(By.cssSelector("input[name='address2']"));
		add2.clear();
		add2.sendKeys("Demo user address 2");
	//Enter password
		driver.findElement(By.id("Password")).sendKeys("demouser");
	//click update profile button
		driver.findElement(By.cssSelector("button[type='submit']")).click();
		System.out.println("Information has been updated successfully");
		Thread.sleep(2000);
		driver.quit();
	}

}
