package net.customer.front_end;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class Customer_functionalities {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		ChromeOptions options=new ChromeOptions();
		options.setBinary("D:\\selenium\\drivers\\Chrome\\chrome-win64\\chrome.exe");
		WebDriver driver=new ChromeDriver(options);
		driver.get("https://www.phptravels.net/login");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//2)Test the links MyBookings, Add funds, My profile and Logout. Test by auto-clicking all the links to verify the functionalities.
	//valid email and password
		Thread.sleep(2000);
		WebElement email=driver.findElement(By.id("email"));
		email.sendKeys("user@phptravels.com");
		WebElement pwd=driver.findElement(By.id("password"));
		pwd.sendKeys("demouser");
		Thread.sleep(2000);
		WebElement login=driver.findElement(By.id("submitBTN"));
		login.click();
		System.out.println("login successfully");
	//MyBookings
		Thread.sleep(2000);
		WebElement Mybooking=driver.findElement(By.xpath("//*[@id=\"fadein\"]/div[1]/div/div/div[2]/ul/li[2]/a"));
		Mybooking.click();
	//MyProfile
		Thread.sleep(2000);
		WebElement Myprofile=driver.findElement(By.xpath("//*[@id=\"fadein\"]/div[1]/div/div/div[2]/ul/li[3]/a"));
		Myprofile.click();
	//Logout
		Thread.sleep(2000);
		WebElement logout=driver.findElement(By.xpath("//*[@id=\"fadein\"]/div[1]/div/div/div[2]/ul/li[4]/a"));
		logout.click();
		driver.close();
		

	}

}
