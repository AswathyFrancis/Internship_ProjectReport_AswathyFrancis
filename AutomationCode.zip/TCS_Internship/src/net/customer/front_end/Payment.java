package net.customer.front_end;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class Payment {

	@SuppressWarnings("deprecation")
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		ChromeOptions options=new ChromeOptions();
		options.setBinary("D:\\selenium\\drivers\\Chrome\\chrome-win64\\chrome.exe");
		WebDriver driver=new ChromeDriver(options);
		driver.get("https://www.phptravels.net/login");
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			
//3) Create a script that would make an automated payment of USD 50 using paypal	
		//login
			Thread.sleep(2000);
			WebElement email=driver.findElement(By.id("email"));
			email.sendKeys("user@phptravels.com");
			WebElement pwd=driver.findElement(By.id("password"));
			pwd.sendKeys("demouser");
			Thread.sleep(2000);
			WebElement login=driver.findElement(By.id("submitBTN"));
			login.click();
			System.out.println("login successfully");
		//make payment in tours
			//select hotels
			WebElement hotel=driver.findElement(By.xpath("//a[contains(text(),'Hotels')]"));
			hotel.click();
			//Search by city and select a city
			WebElement Search=driver.findElement(By.xpath("//span[@id='select2-hotels_city-container']"));
			Search.click();
			driver.findElement(By.xpath("//body/span[1]/span[1]/span[2]/ul[1]/div[1]/div[1]")).click();
			WebElement submit=driver.findElement(By.xpath("//button[@type='submit']"));
			submit.click();

			WebElement Hotelname=driver.findElement(By.xpath("//input[@class='form-control filter--hotel-name']"));
			Hotelname.sendKeys("Armani Hotel Dubai");

			driver.findElement(By.cssSelector("#hotels--list-targets > li.mix.stars_3.hotels_amenities_.row.g-0.bg-white.rounded-2.mb-2.hotel_list.armani-hotel-dubai > div.col-xxl-9.col-xl-9.col-lg-8.ps-3.p-3 > div.d-flex.justify-content-between.rounded-1.mt-3.align-items-center > div.d-flex.gap-2.align-items-center > a")).click();
			Thread.sleep(5000);


			WebElement Booknow=driver.findElement(By.xpath("//*[@id=\"fadein\"]/div[1]/div/div[3]/div[3]/div[2]/form/div/div[4]/div/div/div/button"));
			Booknow.click();

			WebElement Firstname=driver.findElement(By.xpath("//input[@name='user[first_name]']"));
			Firstname.sendKeys("Demo");
			WebElement Lastname=driver.findElement(By.xpath("//input[@name='user[last_name]']"));

			Lastname.sendKeys("User");

			WebElement email1=driver.findElement(By.xpath("//*[@id=\"fadein\"]/div[2]/form/section/div/div/div[1]/div[1]/div[2]/div/div/div[3]/div/input"));
			email1.sendKeys("user@phptravels.com");
			WebElement phonenumber=driver.findElement(By.xpath("//input[@name='user[phone]']"));
			phonenumber.sendKeys("1234567");
			WebElement address=driver.findElement(By.xpath("//input[@name='user[address]']"));
			address.sendKeys("Abc villa");
			WebElement Travellerfirstname=driver.findElement(By.xpath("//input[@name='firstname_1']"));
			Travellerfirstname.sendKeys("Prakash");
			WebElement Travellerlastname=driver.findElement(By.xpath("//*[@id=\"fadein\"]/div[2]/form/section/div/div/div[1]/div[2]/div[2]/div/div[2]/div/div[3]/div/input"));
			Travellerlastname.sendKeys("Raj");
			//driver.findElement(By.xpath("//input[@id='gateway_paypal']")).click();
			Thread.sleep(10000);

			WebElement confirmbooking=driver.findElement(By.xpath("//*[@id=\"booking\"]"));
			confirmbooking.click();
			//proceed the paypal
			WebElement proceed=driver.findElement(By.xpath("//input[@class='btn btn-success w-100']"));
			proceed.click();
			Thread.sleep(5000);
			driver.findElement(By.xpath("//input[@name='login_email']")).sendKeys("sb-itxir5994130@personal.example.com");
			driver.findElement(By.xpath("//button[@name='btnNext']")).click();
			driver.findElement(By.xpath("//input[@name='login_password']")).sendKeys("testpayment");
			driver.findElement(By.xpath("//button[@class='button actionContinue scTrack:unifiedlogin-login-submit']")).click();
			Thread.sleep(2000);
			WebElement Paymentsubmit=driver.findElement(By.xpath("//button[@id='payment-submit-btn']"));
			Paymentsubmit.click();
			WebElement Emailid=driver.findElement(By.xpath("//input[@name='login email']"));
			Emailid.sendKeys("l sb-itxir5994130@personal.example.com");
			driver.findElement(By.xpath("//button[@name='btnNext']")).click();
			WebElement password1=driver.findElement(By.xpath("//input[@name='password']"));
			password1.sendKeys("testpayment");
			driver.findElement(By.xpath("//button[@name='submit']")).click();
			
		
	}




	}


