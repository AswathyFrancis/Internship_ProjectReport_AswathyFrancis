package net.supplier.back_end;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class Suppl_login {

	@SuppressWarnings("deprecation")
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		ChromeOptions options=new ChromeOptions();
		options.setBinary("D:\\selenium\\drivers\\Chrome\\chrome-win64\\chrome.exe");
		WebDriver driver=new ChromeDriver(options);
		driver.get("https://www.phptravels.net/supplier");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
/*//1)LOgin using the credentials. Check for valid and invalid test cases
		//vaild email and password
		Thread.sleep(2000);
		WebElement acc=driver.findElement(By.cssSelector("#navbarSupportedContent > div.nav-item--right > ul > li:nth-child(3) > a"));
		acc.click();
		WebElement login=driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/div[2]/ul/li[3]/ul/li[1]/a"));
		login.click();
		Thread.sleep(2000);
		WebElement email=driver.findElement(By.xpath("//input[@name='email']"));
		email.sendKeys("supplier@phptravels.com");
		WebElement pwd=driver.findElement(By.xpath("//input[@name='password']"));
		pwd.sendKeys("demosupplier");
		driver.findElement(By.xpath("//button[@id='submitBTN']")).click();
		Thread.sleep(3000);
		driver.findElement(By.cssSelector("#fadein > div:nth-child(5) > div > div > div:nth-child(2) > ul > li:nth-child(4) > a")).click();
		System.out.println("Login successfully....");
	//Invalid Login
		Thread.sleep(2000);
		WebElement acc1=driver.findElement(By.cssSelector("#navbarSupportedContent > div.nav-item--right > ul > li:nth-child(3) > a"));
		acc1.click();
		WebElement login1=driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/div[2]/ul/li[3]/ul/li[1]/a"));
		login1.click();
		Thread.sleep(2000);
		WebElement email1=driver.findElement(By.xpath("//input[@name='email']"));
		email1.sendKeys("supplier@phptravels.com");
		WebElement pwd1=driver.findElement(By.xpath("//input[@name='password']"));
		pwd1.sendKeys("demosupplr");
		driver.findElement(By.xpath("//button[@id='submitBTN']")).click();
		Thread.sleep(3000);
		System.out.println("Invalid Login...");*/
		Thread.sleep(2000);
		driver.quit();
		
	}

}
