package net.admin_back_end;

import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Booking_Status {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://phptravels.net/admin/login.php");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			
//3)Create a script that would delete a record having booking status cancelled
			
	//valid login
		Thread.sleep(2000);
		WebElement email=driver.findElement(By.id("email"));
		email.sendKeys("admin@phptravels.com");
		WebElement pwd=driver.findElement(By.id("password"));
		pwd.sendKeys("demoadmin");
		Thread.sleep(2000);
		WebElement login=driver.findElement(By.id("submit"));
		login.click();
		System.out.println("login successfully");
	//Bookings
		driver.findElement(By.cssSelector("body > main > header > ul > li:nth-child(11) > a")).click();
		WebElement bookingdetails=driver.findElement(By.xpath("/html/body/main/section/div[2]/div/div[2]/div/figure/blockquote[2]/div/span/a"));
		bookingdetails.click();
	//invoice
		Thread.sleep(2000);
	       driver.switchTo().defaultContent();
			
			String parentwindow=driver.getWindowHandle();
			Set<String> childwindow=driver.getWindowHandles();
			Iterator<String> i=childwindow.iterator();
			while(i.hasNext())
			{
			String cwindow=i.next();
			if(!parentwindow.equals(cwindow))
			{
				driver.switchTo().window(cwindow);
			}
			}
			System.out.println(driver.getCurrentUrl());
		//proceed
			Thread.sleep(2000);
			driver.findElement(By.xpath("//*[@id=\"form\"]")).click();
		//paypal
			Thread.sleep(2000);
			driver.switchTo().frame("iframe");
			driver.findElement(By.id("paypal-button")).click();
		
}

}
