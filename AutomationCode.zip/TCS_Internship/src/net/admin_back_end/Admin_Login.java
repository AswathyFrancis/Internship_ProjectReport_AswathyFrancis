package net.admin_back_end;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Admin_Login {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		WebDriver driver=new ChromeDriver();
		driver.get("https://phptravels.net/admin/login.php");
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	//1)Login Using the credentials. Check for valid and invalid testcases	
		
		//valid login
			Thread.sleep(2000);
			WebElement email=driver.findElement(By.id("email"));
			email.sendKeys("admin@phptravels.com");
			WebElement pwd=driver.findElement(By.id("password"));
			pwd.sendKeys("demoadmin");
			Thread.sleep(2000);
			WebElement login=driver.findElement(By.id("submit"));
			login.click();
			System.out.println("login successfully");
		//Invalid login
			Thread.sleep(3000);
			driver.findElement(By.cssSelector("#dropdownUser1")).click();
			Thread.sleep(2000);
			driver.findElement(By.linkText("Logout")).click();
			Thread.sleep(2000);
			
			
			Thread.sleep(2000);
			WebElement emailin=driver.findElement(By.id("email"));
			emailin.sendKeys("admin@phptravels.com");
			Thread.sleep(2000);
			WebElement pwdin=driver.findElement(By.id("password"));
			pwdin.sendKeys("demoadn");
			Thread.sleep(1000);
			WebElement loginin=driver.findElement(By.id("submit"));
			loginin.click();
			System.out.println("please check your email and password");
			Thread.sleep(2000);
			driver.quit();
		
	}

}
