package net.admin_back_end;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Admin_Bookings {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		WebDriver driver=new ChromeDriver();
		driver.get("https://phptravels.net/admin/login.php");
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			
	//2)Test the link Bookings and then test display of Booking invoice Where payment is successfull
			
		//valid login
		Thread.sleep(2000);
		WebElement email=driver.findElement(By.id("email"));
		email.sendKeys("admin@phptravels.com");
		WebElement pwd=driver.findElement(By.id("password"));
		pwd.sendKeys("demoadmin");
		Thread.sleep(2000);
		WebElement login=driver.findElement(By.id("submit"));
		login.click();
		System.out.println("login successfully");
		
		//Click Bookings module
		Thread.sleep(2000);
		WebElement booking=driver.findElement(By.cssSelector("body > main > header > ul > li:nth-child(11) > a"));
		booking.click();
		//invoice
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html/body/main/section/div[2]/div/div[2]/figure/blockquote[2]/div/span/a")).click();
		Thread.sleep(5000);
		driver.quit();
	}

}
