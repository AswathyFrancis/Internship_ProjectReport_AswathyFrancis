package net.agent_front_end;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class Search {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		ChromeOptions options=new ChromeOptions();
		options.setBinary("D:\\selenium\\drivers\\Chrome\\chrome-win64\\chrome.exe");
		WebDriver driver=new ChromeDriver(options);
		driver.get("https://www.phptravels.net/login");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//4)Script to search hotels by city and test results.
	//valid email and password
		Thread.sleep(2000);
		WebElement email=driver.findElement(By.id("email"));
		email.sendKeys("agent@phptravels.com");
		WebElement pwd=driver.findElement(By.id("password"));
		pwd.sendKeys("demoagent");
		Thread.sleep(2000);
		WebElement login=driver.findElement(By.id("submitBTN"));
		login.click();
	//Click Hotels
		Thread.sleep(2000);
		WebElement hotel=driver.findElement(By.cssSelector("#navbarSupportedContent > div.nav-item--left.ms-lg-5 > ul > li:nth-child(2) > a"));
		hotel.click();
	//Select city
		WebElement city=driver.findElement(By.xpath("//span[@class='select2-selection__rendered']"));
		city.click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//body/span[1]/span[1]/span[2]/ul[1]/div[1]/div[1]")).click();
		Thread.sleep(2000);
	//click search button
		WebElement search=driver.findElement(By.xpath("//button[@type='submit']"));
		search.click();
		driver.quit();

	}

}
