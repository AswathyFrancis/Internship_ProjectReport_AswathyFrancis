package net.agent_front_end;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;

public class Inr {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		ChromeOptions options=new ChromeOptions();
		options.setBinary("D:\\selenium\\drivers\\Chrome\\chrome-win64\\chrome.exe");
		WebDriver driver=new ChromeDriver(options);
		driver.get("https://www.phptravels.net/login");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//Develop the script that would update USD to INR for the account.
	//valid email and password
		Thread.sleep(2000);
		WebElement email=driver.findElement(By.id("email"));
		email.sendKeys("agent@phptravels.com");
		WebElement pwd=driver.findElement(By.id("password"));
		pwd.sendKeys("demoagent");
		Thread.sleep(2000);
		WebElement login=driver.findElement(By.id("submitBTN"));
		login.click();
	//Click USD
		Thread.sleep(2000);
		WebElement usd=driver.findElement(By.cssSelector("#navbarSupportedContent > div.nav-item--right > ul > li:nth-child(2) > a"));
		usd.click();
	//select INR
		Thread.sleep(2000);
		WebElement inr=driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/div[2]/ul/li[2]/ul/li[4]/a"));
		inr.click();
		driver.quit();
		

	}

}
