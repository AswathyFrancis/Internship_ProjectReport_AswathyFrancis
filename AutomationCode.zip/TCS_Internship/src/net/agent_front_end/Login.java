package net.agent_front_end;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class Login {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		ChromeOptions options=new ChromeOptions();
		options.setBinary("D:\\selenium\\drivers\\Chrome\\chrome-win64\\chrome.exe");
		WebDriver driver=new ChromeDriver(options);
		Thread.sleep(3000);
		driver.get("https://www.phptravels.net");
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			
//1)Login using the credentials. Check for valid and invalid test cases		
		//Valid Login
			driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/div[2]/ul/li[3]/a/strong")).click();
			driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/div[2]/ul/li[3]/ul/li[1]/a")).click();
			Thread.sleep(2000);
			WebElement email=driver.findElement(By.id("email"));
			email.sendKeys("agent@phptravels.com");
			WebElement pwd=driver.findElement(By.id("password"));
			pwd.sendKeys("demoagent");
			Thread.sleep(2000);
			WebElement login=driver.findElement(By.id("submitBTN"));
			login.click();
			System.out.println("login successfully");
		//Invalid login
			Thread.sleep(2000);
			driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/div[2]/ul/li[3]/a/strong")).click();
			Thread.sleep(2000);
			driver.findElement(By.linkText("Logout")).click();
			Thread.sleep(2000);
			driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/div[2]/ul/li[3]/a/strong")).click();
			driver.findElement(By.xpath(" //*[@id=\"navbarSupportedContent\"]/div[2]/ul/li[3]/ul/li[1]/a")).click();
			Thread.sleep(2000);
			WebElement emailin=driver.findElement(By.id("email"));
			emailin.sendKeys("agent@phptravels.com");
			Thread.sleep(2000);
			WebElement pwdin=driver.findElement(By.id("password"));
			pwdin.sendKeys("demoagnt");
			Thread.sleep(2000);
			WebElement loginin=driver.findElement(By.id("submitBTN"));
			loginin.click();
			System.out.println("Invalid login...");
		
			Thread.sleep(3000);
			driver.quit();


	}

}
